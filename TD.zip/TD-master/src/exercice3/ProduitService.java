package exercice3;

import java.util.List;
import java.util.stream.Collectors;

public class ProduitService {

    public static List<Produit> transformerProduits(List<Produit> produits) {
        return produits.stream()
                .map(p -> {
                    if (p.getCategorie().equals("Electronique") && p.getPrix() < 2000) {
                        p.setPrix(p.getPrix() * 0.85);
                    }

                    if (!p.getCategorie().equals("Librairie") &&
                            !p.getCategorie().equals("Jardin")) {
                        p.setId(p.getCategorie().substring(0, 3).toUpperCase() + "-" + p.getId());
                    }
                    return p;
                })
                .collect(Collectors.toList());
    }
}
