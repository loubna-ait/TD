package exercice7;

import java.sql.Connection;

public class TaskExeQuery extends Thread {
    public Connection connection;
    public String query;

    public TaskExeQuery(Connection connection, String query) {
        this.connection = connection;
        this.query = query;
    }

    public void run() {
        Operations.execQuery(query, connection);
    }
}
