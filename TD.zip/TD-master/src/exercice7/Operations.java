package exercice7;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Operations {
    // 1️⃣ Méthode sécurisée (Version Synchronized)
    public static synchronized void execQuery(String query, Connection con) {
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            statement = con.createStatement();
            resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String valCol = resultSet.getString("hometown");
                System.out.println(valCol);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
