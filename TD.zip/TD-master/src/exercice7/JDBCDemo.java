package exercice7;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCDemo {
    // 1️⃣ Méthode sécurisée
    public static synchronized void execQuery(String sql) {
        // Simulation JDBC
        System.out.println("Exécution de la requête: " + sql);
    }

    public static void main(String[] args) {
        // Explications de base
        System.out.println("DriverManager : gère les drivers JDBC");
        System.out.println("jdbc:mysql:// : URL de connexion à MySQL");

        execQuery("SELECT * FROM Personnel");
    }
}
