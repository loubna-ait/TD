package exercice7;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MainEx {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1/ourDataBase";
        String user = "root";
        String password = "";
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TaskExeQuery task1 = new TaskExeQuery(connection, "SELECT * FROM membre");
        TaskExeQuery task2 = new TaskExeQuery(connection, "SELECT hm FROM membre");

        Thread th1 = new Thread(task1);
        Thread th2 = new Thread(task2);

        // 2️⃣ Exécution avec attente
        th1.start();
        try {
            th1.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        th2.start();
    }
}
