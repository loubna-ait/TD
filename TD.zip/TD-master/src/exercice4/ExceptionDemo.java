package exercice4;

public class ExceptionDemo {
    public static void main(String[] args) {
        try {
            // code à risque
            String str = null;
            System.out.println(str.length());
        } catch (NullPointerException e) {
            System.out.println("Erreur Null pointer trouvée");
        }
    }
}
