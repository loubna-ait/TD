import exercice1.*;
import exercice2.*;
import exercice3.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("===== Démonstration des Exercices Java =====");

        // Exercice 1
        Gerant g1 = new Gerant("Ali", 12000, 2015, "Informatique");
        Gerant g2 = new Gerant("Sara", 11000, 2016, "Finance");

        Assistant a1 = new Assistant("Omar", 5000, 2020);
        Assistant a2 = new Assistant("Hana", 5200, 2021);

        Departement d1 = new Departement("IT");
        Departement d2 = new Departement("RH");

        g1.ajouterDepartement(d1);
        g2.ajouterDepartement(d2);

        System.out.println("Gérant g1: " + g1.nom + " gère " + d1.getNom());

        // Exercice 2
        Set<Departement> lesDeps = new HashSet<>();
        lesDeps.add(d1);
        lesDeps.add(d2);

        PersonnelService.ajouterDepartement(lesDeps, "Marketing", g1);
        System.out.println("Nombre de départements après ajout: " + lesDeps.size());

        // Exercice 3
        List<Produit> produits = new ArrayList<>();
        produits.add(new Produit("12", "Laptop", "Electronique", 1500));
        produits.add(new Produit("5", "Livre Java", "Librairie", 50));

        List<Produit> transformes = ProduitService.transformerProduits(produits);
        System.out.println("ID transformé: " + transformes.get(0).getId());

        System.out.println("\n===== Fin de la simulation =====");
    }
}
