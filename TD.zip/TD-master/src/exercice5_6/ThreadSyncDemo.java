package exercice5_6;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ThreadSyncDemo {
    private static int counter = 0;
    private static final Lock lock = new ReentrantLock();

    // Méthode sécurisée (synchronized)
    public static synchronized void incrementSync() {
        counter++;
    }

    // Méthode sécurisée (Lock)
    public static void incrementWithLock() {
        lock.lock();
        try {
            counter++;
        } finally {
            lock.unlock();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread th1 = new Thread(() -> {
            for (int i = 0; i < 1000; i++)
                incrementSync();
        });

        Thread th2 = new Thread(() -> {
            for (int i = 0; i < 1000; i++)
                incrementWithLock();
        });

        // Exécution avec attente
        th1.start();
        th1.join(); // attend la fin de th1
        th2.start();
        th2.join(); // attend la fin de th2

        System.out.println("Compteur final: " + counter);
    }
}
