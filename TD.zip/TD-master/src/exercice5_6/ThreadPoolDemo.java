package exercice5_6;

import java.util.concurrent.*;

public class ThreadPoolDemo {
    public static void main(String[] args) {
        // threads
        ExecutorService executor = Executors.newFixedThreadPool(7);

        // submit() → lance la tâche + retourne un Future
        for (int i = 0; i < 10; i++) {
            final int taskId = i;
            executor.submit(() -> {
                System.out.println("Exécution tâche " + taskId + " par " + Thread.currentThread().getName());
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
        }

        executor.shutdown();
    }
}
