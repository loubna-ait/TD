package exercice1;

import java.util.HashSet;
import java.util.Set;

public class Gerant extends Personnel {
    private String specialite;
    private Set<Departement> departements; // one-to-many

    public Gerant(String nom, double salaire, int anneeDebut, String specialite) {
        super(nom, salaire, anneeDebut);
        this.specialite = specialite;
        this.departements = new HashSet<>();
    }

    public void ajouterDepartement(Departement d) {
        departements.add(d);
        d.setGerant(this);
    }

    public void supprimerDepartement(Departement d) {
        departements.remove(d);
        d.setGerant(null);
    }

    public String getSpecialite() {
        return specialite;
    }
}
