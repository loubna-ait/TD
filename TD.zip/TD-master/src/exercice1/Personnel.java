package exercice1;

public abstract class Personnel {
    public String nom;
    public double salaire;
    public int anneeDebut;

    public Personnel(String nom, double salaire, int anneeDebut) {
        this.nom = nom;
        this.salaire = salaire;
        this.anneeDebut = anneeDebut;
    }
}
