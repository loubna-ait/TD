package exercice1;

public class Departement {
    private String nom;
    private Gerant gerant; // one-to-one

    public Departement(String nom) {
        this.nom = nom;
    }

    public void setGerant(Gerant gerant) {
        this.gerant = gerant;
    }

    public String getNom() {
        return nom;
    }

    public Gerant getGerant() {
        return gerant;
    }
}
