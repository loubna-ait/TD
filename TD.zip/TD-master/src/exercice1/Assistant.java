package exercice1;

public class Assistant extends Personnel {

    public Assistant(String nom, double salaire, int anneeDebut) {
        super(nom, salaire, anneeDebut);
    }
}
