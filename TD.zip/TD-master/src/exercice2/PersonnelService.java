package exercice2;

import exercice1.Departement;
import exercice1.Gerant;
import exercice1.Personnel;
import exercice1.Assistant;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class PersonnelService {

    // 1️⃣ Ajouter un département (nom unique + gérant obligatoire)
    public static boolean ajouterDepartement(Set<Departement> lesDeps,
            String nom,
            Gerant gerant) {
        for (Departement d : lesDeps) {
            if (d.getNom().equals(nom)) {
                return false;
            }
        }
        Departement dep = new Departement(nom);
        gerant.ajouterDepartement(dep);
        lesDeps.add(dep);
        return true;
    }

    // 2️⃣ Supprimer un département
    public static void supprimerDepartement(Set<Departement> lesDeps, Departement dep) {
        if (dep.getGerant() != null) {
            dep.getGerant().supprimerDepartement(dep);
        }
        lesDeps.remove(dep);
    }

    // 3️⃣ Nombre d’assistants par salaire
    public static Map<Double, Long> nombreAssistantsParSalaire(List<Personnel> lesPrs) {
        return lesPrs.stream()
                .filter(p -> p instanceof Assistant)
                .map(p -> (Assistant) p)
                .collect(Collectors.groupingBy(
                        a -> a.salaire,
                        Collectors.counting()));
    }

    // 4️⃣ Gérants (salaire < 10000) par spécialité
    public static Map<String, List<Gerant>> gerantsParSpecialite(List<Personnel> lesPrs) {
        return lesPrs.stream()
                .filter(p -> p instanceof Gerant)
                .map(p -> (Gerant) p)
                .filter(g -> g.salaire < 10000)
                .collect(Collectors.groupingBy(Gerant::getSpecialite));
    }
}
