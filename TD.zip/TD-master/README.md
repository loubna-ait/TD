# Java Exercises Summary

## Exercice 1 – Classes Java et relations

### Partie 1

* On a : un Gérant et un Département, avec la relation suivante :

  * Un gérant peut gérer plusieurs départements → one-to-many.
  * Un département est géré par un seul gérant → one-to-one côté département.

## Exercice 5 – ThreadPoolExecutor / ExecutorService

* Critères : nombre de threads nécessaires, tâches CPU vs I/O, durée des tâches, consommation mémoire.
* Déclaration 7 threads :

```java
ExecutorService executor = Executors.newFixedThreadPool(7);
```

* Une classe héritant de Thread représente une tâche exécutable en parallèle.
* `run()` contient le code à exécuter dans le thread.
* `submit()` soumet une tâche au pool et retourne un `Future` pour récupérer le résultat.
* File d’attente : structure FIFO pour stocker les tâches en attente.
* Problèmes possibles : deadlock, starvation, surcharge mémoire.
* `Collection<Future<?>>` : permet de suivre et récupérer les résultats de toutes les tâches soumises.

## Exercice 6 – Synchronisation

* Empêche les conflits quand plusieurs threads accèdent à des données partagées.
* Résout les problèmes de concurrence : écrasement de valeurs, lecture de données incohérentes.
* `Lock` : mécanisme manuel pour verrouiller un bloc de code ; `lock.lock()` / `lock.unlock()`.
* `synchronized` : mot-clé pour protéger un bloc ou une méthode.
* On peut simuler un problème en accédant simultanément à une variable partagée.
* Points clé : identifier les sections critiques, minimiser la portée du verrou.
* Section critique : code accédant à une ressource partagée.
* `start()` démarre le thread, `join()` attend sa fin.

## Exercice 7 – Threads SQL

* a) Avec `synchronized` :

```java
public static synchronized void execQuery(String query, Connection con) { ... }
```

* b) Avec `Lock` :

```java
private static Lock lock = new ReentrantLock();
public static void execQuery(String query, Connection con) {
    lock.lock();
    try { ... }
    finally { lock.unlock(); }
}
```

* Exécution th2 après th1 :

```java
th1.start();
th1.join();
th2.start();
```

* a) `DriverManager` : permet d’obtenir la connexion à la base.
* b) `jdbc:mysql://` : protocole pour connecter Java à MySQL

## Exercice 7 – Hibernate

* **Annotations :**

  * `@Entity` : classe persistante.
  * `@Table(name="departement")` : table associée.
  * `@Id` : clé primaire.
  * `@GeneratedValue` : génération automatique de l’id.
  * `@Column` : mappe un attribut à une colonne.
  * `@OneToMany(mappedBy="departement", ...)` : relation un-à-plusieurs.

* **Classe Livre :**

```java
@Entity
@Table(name="livre")
public class Livre {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idLivre;

    @Column(nullable = false)
    private String titre;

    @ManyToOne
    @JoinColumn(name = "idDep")
    private Departement departement;

    // getters & setters
}
```

* `cascade = CascadeType.ALL` : toutes les opérations (save, delete, update) sur Département affectent ses livres.

* **Hibernate DAO :**

  * `Transaction` : unité de travail.
  * `beginTransaction()` : démarre transaction.
  * `createQuery` : exécute requête HQL.
  * `commit` : valide la transaction.
  * `SessionFactory` : crée des sessions Hibernate.

* **Méthode updateDepartement :**

```java
public void updateDepartement(Departement dep) {
    Session session = sessionFactory.openSession();
    Transaction tx = session.beginTransaction();
    session.update(dep);
    tx.commit();
    session.close();
}
```

* **Concepts Java EE et persistance :**

  * Jakarta : standard pour Java EE.
  * ORM : mappe les objets Java sur la BD.
  * Persistance : stockage durable des données.
